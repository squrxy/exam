Сюда кладите фото товаров (jpg/png). Путь к файлу прописывается в БД, поле Products.image_path, например images/palermo.jpg
