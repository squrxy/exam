import os
from PyQt6.QtWidgets import QInputDialog, QMessageBox
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap, QPainter, QColor
from db import run_query

# Запрос списка товаров. Подтягиваем названия категории, бренда и поставщика
# из связанных таблиц, чтобы в карточке показывать текст, а не id.
PRODUCT_SQL = """
    SELECT
        p.*,
        c.name as category,
        m.name as manufacture,
        s.name as supplier
    FROM Products p
    LEFT JOIN Categories c ON p.category_id = c.category_id
    LEFT JOIN Manufacturers m ON p.manufacture_id = m.manufacture_id
    LEFT JOIN Suppliers s ON p.supplier_id = s.supplier_id
"""


# Формирует HTML с ценой для карточки товара.
def price_html(price, discount):
    price, discount = float(price), float(discount)
    if discount > 0:
        # если есть скидка - считаем итоговую цену
        final = round(price * (1 - discount / 100), 2)
        # старую цену зачёркиваем красным, итоговую пишем чёрным (по образцу из задания)
        return (
            f'<span style="color: red; text-decoration: line-through"> {price:.0f} Р. </span> '
            f'<span style="color: black; font-weight: bold;">{final:.0f} Р.</span>'
        )
    # скидки нет - просто цена
    return f'<b>{price:.0f} Р.</b>'


# Подбирает цвет фона карточки в зависимости от остатка и скидки.
def card_style(stock, discount):
    discount = float(discount or 0)
    stock = int(stock or 0)
    st = "border-radius: 8px; border: 1px solid #ddd; padding: 6px; "

    # порядок важен: сначала проверяем наличие, потом скидку
    if stock <= 0:
        st += "background-color: #B3E5FC;"                    # нет на складе - голубой
    elif discount > 15:
        st += "background-color: #2E8B57; color: white;"      # большая скидка - зелёный
    else:
        st += "background-color: #FFFFFF;"
    return st


# Готовит картинку товара 80x80. Если файла нет - рисует заглушку "No Photo".
def get_product_pixmap(path):
    pix = QPixmap(80, 80)
    if path and os.path.exists(path):
        pix.load(path)
        return pix.scaled(80, 80, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)

    # фото нет - сами рисуем серый прямоугольник с подписью
    pix.fill(QColor("#E0E0E0"))
    painter = QPainter(pix)
    painter.setPen(QColor("#757575"))
    painter.drawText(pix.rect(), Qt.AlignmentFlag.AlignCenter, "No Photo")
    painter.end()
    return pix


# Действия администратора с товарами: добавить, удалить, изменить.
# Вынес в отдельный класс, чтобы не загромождать главное окно.
class ProductManager:
    # Добавление нового товара (название, цена, остаток спрашиваем по очереди).
    @staticmethod
    def add_product(parent_window):
        name, ok1 = QInputDialog.getText(parent_window, "Добавить", "Название обуви:")
        if not ok1 or not name:
            return
        price, ok2 = QInputDialog.getDouble(parent_window, "Добавить", "Цена (Р):", 5000, 0, 999999, 2)
        if not ok2:
            return
        stock, ok3 = QInputDialog.getInt(parent_window, "Добавить", "Остаток на складе:", 10, 0, 99999)
        if ok3:
            # категорию/бренд/поставщика ставим первыми по умолчанию (1)
            run_query(
                "INSERT INTO Products (name, category_id, manufacture_id, supplier_id, price, unit, quantity, discount) "
                "VALUES (%s, 1, 1, 1, %s, 'шт', %s, 0)",
                (name, price, stock),
            )
            parent_window.load_product()

    # Удаление товара по точному названию.
    @staticmethod
    def delete_product(parent_window):
        name, ok = QInputDialog.getText(parent_window, "Удалить товар", "Введите точное название для удаления:")
        if not ok or not name:
            return
        row = run_query("SELECT product_id FROM Products WHERE name=%s", (name,), fetch='one')
        if not row:
            QMessageBox.warning(parent_window, "Ошибка", "Товар с таким названием не найден")
            return

        # товар, который уже есть в заказах, удалять нельзя - иначе нарушится целостность БД
        cnt = run_query(
            "SELECT COUNT(*) AS c FROM OrderItems WHERE product_id=%s",
            (row['product_id'],), fetch='one'
        )
        if cnt and cnt['c'] > 0:
            QMessageBox.warning(parent_window, "Ошибка", "Нельзя удалить товар, так как он уже есть в заказах!")
            return

        run_query("DELETE FROM Products WHERE product_id = %s", (row['product_id'],))
        QMessageBox.information(parent_window, "Успешно", "Товар удален")
        parent_window.load_product()

    # Изменение цены и остатка у существующего товара.
    @staticmethod
    def change_product(parent_window):
        name, ok = QInputDialog.getText(parent_window, "Изменить товар", "Введите точное название товара:")
        if not ok or not name:
            return

        product = run_query("SELECT * FROM Products WHERE name=%s", (name,), fetch='one')
        if not product:
            QMessageBox.warning(parent_window, "Ошибка", "Товар не найден!")
            return

        # в диалогах сразу показываем текущие значения, чтобы было видно, что меняем
        new_price, ok_p = QInputDialog.getDouble(
            parent_window, "Изменение", f"Старая цена: {product['price']} Р.\nНовая цена:",
            float(product['price']), 0, 999999, 2
        )
        if not ok_p:
            return

        new_qty, ok_q = QInputDialog.getInt(
            parent_window, "Изменение", f"Текущий остаток: {product['quantity']} шт.\nНовый остаток:",
            int(product['quantity']), 0, 99999
        )
        if not ok_q:
            return

        run_query(
            "UPDATE Products SET price=%s, quantity=%s WHERE product_id=%s",
            (new_price, new_qty, product['product_id'])
        )
        QMessageBox.information(parent_window, "Успешно", "Данные товара обновлены")
        parent_window.load_product()
