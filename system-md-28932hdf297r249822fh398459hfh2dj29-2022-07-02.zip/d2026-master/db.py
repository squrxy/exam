import pymysql


# Подключение к базе данных MySQL.
# DictCursor нужен, чтобы строки приходили как словари (обращаемся к полям по имени).
def get_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='root',
        database='shoes',
        cursorclass=pymysql.cursors.DictCursor
    )


# Одна функция на все запросы к БД, чтобы не дублировать открытие/закрытие соединения.
# fetch='one'  - вернуть одну строку
# fetch='all'  - вернуть список строк
# fetch=None   - это INSERT/UPDATE/DELETE: коммитим и возвращаем id новой записи
def run_query(query, params=(), fetch=None):
    conn = get_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            if fetch == 'one':
                return cursor.fetchone()
            if fetch == 'all':
                return cursor.fetchall()
            conn.commit()
            return cursor.lastrowid
    finally:
        # соединение закрываем в любом случае, даже если был сбой
        conn.close()


# Проверка логина и пароля.
# Join с таблицей ролей, чтобы сразу узнать роль и ФИО пользователя.
# Если пара логин/пароль не найдена - вернётся None.
def auth(login, password):
    query = """
        SELECT u.user_id, u.username, u.last_name, u.first_name, u.patronymic, r.role_name
        FROM Users u
        JOIN Roles r ON r.role_id = u.role_id
        WHERE u.username = %s AND u.passw = %s
    """
    return run_query(query, (login, password), fetch='one')
