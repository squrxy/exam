import os
import sys
from PyQt6.QtWidgets import *
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
from db import run_query
from product import PRODUCT_SQL, price_html, card_style, get_product_pixmap, ProductManager


# Собирает ФИО из полей пользователя. У гостя этих полей нет - вернём "Гость".
def full_name(user):
    parts = [user.get('last_name'), user.get('first_name'), user.get('patronymic')]
    fio = ' '.join(p for p in parts if p)
    return fio or 'Гость'


# Главное окно приложения. Что видит пользователь, зависит от его роли.
class AppWindow(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.role = self.user['role_name']
        self.sort_asc = True  # текущее направление сортировки по остатку
        self.resize(900, 600)
        self.setWindowTitle(f"Магазин обуви {self.role.upper()}")

        # иконка приложения, если файл лежит рядом с программой
        if os.path.exists("img1.png"):
            self.setWindowIcon(QIcon("img1.png"))

        # всё содержимое кладём во вкладки
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.menu_tab = QWidget()
        self.tabs.addTab(self.menu_tab, 'Меню товаров')
        self.setup_menu()

        # ФИО пользователя в правом верхнем углу (требование задания)
        fio = QLabel(full_name(user) + "  ")
        fio.setStyleSheet("font-weight: bold; padding-right: 6px;")
        self.menuBar().setCornerWidget(fio, Qt.Corner.TopRightCorner)

    # Выход из аккаунта = перезапуск программы, снова открывается окно входа.
    def logout(self):
        os.execl(sys.executable, sys.executable, *sys.argv)

    # Небольшой помощник, чтобы не повторять создание кнопки три раза.
    def add_btn(self, text, func, layout):
        btn = QPushButton(text)
        btn.clicked.connect(func)
        layout.addWidget(btn)
        return btn

    # Собирает интерфейс вкладки с товарами: кнопки, фильтры и сам список.
    def setup_menu(self):
        layout = QVBoxLayout(self.menu_tab)
        admin_layout = QHBoxLayout()

        # пункт "Выйти" в меню сверху - доступен всем
        exit_btn = self.menuBar().addAction("Выйти")
        exit_btn.triggered.connect(self.logout)

        # кнопки работы с товарами - только администратору
        if self.role == 'admin':
            self.add_btn('Добавить товар', lambda: ProductManager.add_product(self), admin_layout)
            self.add_btn('Удалить товар', lambda: ProductManager.delete_product(self), admin_layout)
            self.add_btn('Изменить цену/остаток', lambda: ProductManager.change_product(self), admin_layout)

        # заказы доступны и админу, и менеджеру
        if self.role in ['admin', 'manager']:
            self.add_btn('Заказы', self.manage_orders, admin_layout)

        layout.addLayout(admin_layout)

        # Поиск, фильтр и сортировка - всем кроме обычного клиента (и гостя).
        # Заранее ставим None, чтобы load_product понимал, что фильтров нет.
        self.search = None
        self.supplier_cb = None
        self.sort_btn = None
        if self.role != 'client':
            filt = QHBoxLayout()

            # строка поиска - перерисовываем список при каждом изменении текста
            self.search = QLineEdit()
            self.search.setPlaceholderText("Поиск...")
            self.search.textChanged.connect(self.load_product)

            # выпадающий список поставщиков, первый пункт "Все поставщики" сбрасывает фильтр
            self.supplier_cb = QComboBox()
            self.supplier_cb.addItem('Все поставщики', None)
            for s in run_query("SELECT supplier_id, name FROM Suppliers", fetch='all') or []:
                self.supplier_cb.addItem(s['name'], s['supplier_id'])
            self.supplier_cb.currentIndexChanged.connect(self.load_product)

            # кнопка переключения направления сортировки по складу
            self.sort_btn = QPushButton("Склад: По возрастанию")
            self.sort_btn.clicked.connect(self.toggle_sort)

            filt.addWidget(QLabel('Поиск:'))
            filt.addWidget(self.search)
            filt.addWidget(QLabel('Поставщик:'))
            filt.addWidget(self.supplier_cb)
            filt.addWidget(self.sort_btn)
            layout.addLayout(filt)

        # прокручиваемая область, в которую складываем карточки товаров
        scroll = QScrollArea(widgetResizable=True)
        self.grid_w = QWidget()
        self.grid = QGridLayout(self.grid_w)
        scroll.setWidget(self.grid_w)
        layout.addWidget(scroll)
        self.load_product()

    # Меняет направление сортировки и перерисовывает список.
    def toggle_sort(self):
        if not self.sort_btn:
            return
        self.sort_asc = not self.sort_asc
        self.sort_btn.setText(f"Склад: {'По возрастанию' if self.sort_asc else 'По убыванию'}")
        self.load_product()

    # Загружает товары из БД и рисует карточки с учётом поиска/фильтра/сортировки.
    def load_product(self):
        # сначала убираем старые карточки из сетки
        for i in reversed(range(self.grid.count())):
            self.grid.itemAt(i).widget().setParent(None)

        products = run_query(PRODUCT_SQL, fetch='all') or []
        search = self.search.text().strip().lower() if self.search else ''
        sup_id = self.supplier_cb.currentData() if self.supplier_cb else None

        # отбираем товары под текущие фильтр и поиск
        filtered = []
        for p in products:
            # фильтр по поставщику
            if sup_id and p.get('supplier_id') != sup_id:
                continue
            # поиск сразу по всем текстовым полям товара
            if search:
                text = ' '.join(str(p.get(k) or '') for k in (
                    'name', 'category', 'manufacture', 'supplier', 'description'
                )).lower()
                if search not in text:
                    continue
            filtered.append(p)

        # сортировка по остатку (там, где она вообще доступна)
        if self.role != 'client':
            filtered.sort(key=lambda x: int(x.get('quantity') or 0), reverse=not self.sort_asc)

        # рисуем карточку на каждый товар
        for i, p in enumerate(filtered):
            card = QFrame()
            card.setStyleSheet(card_style(p['quantity'], p['discount']))
            card.setMinimumHeight(140)  # минимум, а не фикс - иначе обрезает нижнюю строку с ценой
            h = QHBoxLayout(card)

            # картинка товара (или заглушка)
            img_lbl = QLabel()
            img_lbl.setPixmap(get_product_pixmap(p.get('image_path')))
            img_lbl.setFixedSize(80, 80)

            # текстовое описание товара
            info = QLabel(
                f"<span style='font-size:14px;'><b>{p['name']}</b></span><br>"
                f"Категория: {p.get('category') or '-'} | Бренд: {p.get('manufacture') or '-'} | "
                f"Поставщик: {p.get('supplier') or '-'}<br>"
                f"Описание: {p.get('description') or '—'}<br>"
                f"Наличие: <b>{p['quantity']} {p['unit']}</b><br>"
                f"Цена: {price_html(p['price'], p['discount'])}"
            )
            info.setWordWrap(True)

            h.addWidget(img_lbl)
            h.addWidget(info)
            h.addStretch()

            # бейдж со скидкой показываем, только если скидка реально есть
            if float(p.get('discount') or 0) > 0:
                discount_box = QLabel(f"Скидка\n{float(p['discount']):.0f}%")
                discount_box.setAlignment(Qt.AlignmentFlag.AlignCenter)
                discount_box.setFixedSize(80, 50)
                discount_box.setStyleSheet(
                    "background-color: #FFF3CD; border: 1px solid #FFC107; "
                    "border-radius: 6px; font-weight: bold; color: #6D4C00;"
                )
                h.addWidget(discount_box)

            self.grid.addWidget(card, i, 0)

    # Окно управления заказами (для админа и менеджера).
    def manage_orders(self):
        d = QDialog(self)
        d.setWindowTitle("Управление заказами")
        d.resize(700, 450)
        lay = QVBoxLayout(d)

        # статусы заказов из БД + словарь "название -> id" для удобства
        db_statuses = run_query("SELECT status_id, name FROM Status", fetch='all') or []
        status_map = {s['name']: s['status_id'] for s in db_statuses}

        # выпадающий список для фильтра по статусу ("Все" + все статусы)
        filter_options = ["Все"] + [s['name'] for s in db_statuses]
        cb = QComboBox()
        cb.addItems(filter_options)

        top = QHBoxLayout()
        top.addWidget(QLabel("<b>Фильтр по статусу заказа:</b>"))
        top.addWidget(cb)
        # добавлять заказы может только администратор
        if self.role == 'admin':
            add_order_btn = QPushButton("Добавить заказ")
            top.addWidget(add_order_btn)
        lay.addLayout(top)

        lst = QListWidget()
        lay.addWidget(lst)

        # Заполняет список заказов с учётом выбранного фильтра по статусу.
        def load():
            lst.clear()
            sql = """
                SELECT o.order_id, o.status_id, o.address, o.order_date,
                       u.last_name, u.first_name, s.name as status_name
                FROM Orders o
                LEFT JOIN Users u ON o.user_id = u.user_id
                INNER JOIN Status s ON o.status_id = s.status_id
                ORDER BY o.order_id DESC
            """
            for r in run_query(sql, fetch='all') or []:
                # пропускаем заказы, не подходящие под фильтр
                if cb.currentText() != "Все" and r['status_name'] != cb.currentText():
                    continue
                buyer = f"{r.get('last_name') or ''} {r.get('first_name') or ''}".strip() or "Гость"
                item_text = f"Заказ #{r['order_id']} от {str(r['order_date'])} | Клиент: {buyer} | Статус: [{r['status_name']}]"
                item = QListWidgetItem(item_text)
                # прячем все данные заказа в сам элемент списка - пригодятся при смене статуса
                item.setData(Qt.ItemDataRole.UserRole, r)
                lst.addItem(item)

        # Смена статуса заказа по двойному клику (только админ).
        def change(item):
            if self.role != 'admin':
                QMessageBox.warning(d, "Отказ", "Изменять статус заказов может только Администратор!")
                return

            order_data = item.data(Qt.ItemDataRole.UserRole)
            statuses_list = [s['name'] for s in db_statuses]
            # в диалоге заранее выделяем текущий статус заказа
            try:
                current_idx = statuses_list.index(order_data['status_name'])
            except ValueError:
                current_idx = 0

            res, ok = QInputDialog.getItem(d, "Изменение статуса",
                                           f"Новый статус для заказа #{order_data['order_id']}:", statuses_list,
                                           current_idx, False)
            if ok and res:
                run_query(
                    "UPDATE Orders SET status_id=%s WHERE order_id=%s",
                    (status_map[res], order_data['order_id']),
                )
                QMessageBox.information(d, "Успешно", "Статус заказа обновлен")
                load()

        # Добавление нового заказа (только админ).
        def add_order():
            if self.role != 'admin':
                QMessageBox.warning(d, "Отказ", "Добавлять заказы может только Администратор!")
                return

            # берём клиентов и товары, которые есть в наличии
            clients = run_query(
                """
                SELECT u.user_id, u.username, u.last_name, u.first_name
                FROM Users u
                INNER JOIN Roles r ON r.role_id = u.role_id
                WHERE r.role_name = 'client'
                ORDER BY u.last_name, u.first_name, u.username
                """,
                fetch='all',
            ) or []
            products = run_query(
                "SELECT product_id, name, quantity FROM Products WHERE quantity > 0 ORDER BY name",
                fetch='all',
            ) or []

            # без клиентов/товаров/статусов заказ оформить не получится
            if not clients:
                QMessageBox.warning(d, "Ошибка", "Нет клиентов для оформления заказа")
                return
            if not products:
                QMessageBox.warning(d, "Ошибка", "Нет товаров в наличии")
                return
            if not db_statuses:
                QMessageBox.warning(d, "Ошибка", "Нет статусов заказа")
                return

            # готовим подписи для выпадающих списков: "текст -> данные"
            client_items = {}
            for client in clients:
                fio = f"{client.get('last_name') or ''} {client.get('first_name') or ''}".strip()
                label = f"{fio or client['username']} (ID {client['user_id']})"
                client_items[label] = client

            product_items = {}
            for product in products:
                label = f"{product['name']} - остаток {product['quantity']} шт. (ID {product['product_id']})"
                product_items[label] = product

            # шаг за шагом спрашиваем клиента, товар, количество, адрес и статус
            client_label, ok = QInputDialog.getItem(
                d, "Добавить заказ", "Клиент:", list(client_items.keys()), 0, False
            )
            if not ok or not client_label:
                return

            product_label, ok = QInputDialog.getItem(
                d, "Добавить заказ", "Товар:", list(product_items.keys()), 0, False
            )
            if not ok or not product_label:
                return

            # количество ограничиваем тем, что есть на складе
            product = product_items[product_label]
            qty, ok = QInputDialog.getInt(
                d, "Добавить заказ", "Количество:", 1, 1, int(product['quantity'])
            )
            if not ok:
                return

            address, ok = QInputDialog.getText(d, "Добавить заказ", "Адрес доставки:", text="-")
            if not ok:
                return
            address = address.strip() or "-"

            # по умолчанию предлагаем статус "Новый"
            statuses_list = [s['name'] for s in db_statuses]
            default_idx = next((i for i, s in enumerate(db_statuses) if s['name'] == "Новый"), 0)
            status_name, ok = QInputDialog.getItem(
                d, "Добавить заказ", "Статус:", statuses_list, default_idx, False
            )
            if not ok or not status_name:
                return

            # создаём заказ, добавляем в него товар и списываем остаток со склада
            order_id = run_query(
                "INSERT INTO Orders (user_id, status_id, address, order_date) VALUES (%s, %s, %s, CURDATE())",
                (client_items[client_label]['user_id'], status_map[status_name], address),
            )
            run_query(
                "INSERT INTO OrderItems (order_id, product_id, quantity) VALUES (%s, %s, %s)",
                (order_id, product['product_id'], qty),
            )
            run_query(
                "UPDATE Products SET quantity = quantity - %s WHERE product_id = %s",
                (qty, product['product_id']),
            )

            QMessageBox.information(d, "Успешно", f"Заказ #{order_id} добавлен")
            self.load_product()  # остаток изменился - обновим и список товаров
            load()

        # связываем элементы с обработчиками
        cb.currentTextChanged.connect(load)
        lst.itemDoubleClicked.connect(change)
        if self.role == 'admin':
            add_order_btn.clicked.connect(add_order)

        load()
        d.exec()
