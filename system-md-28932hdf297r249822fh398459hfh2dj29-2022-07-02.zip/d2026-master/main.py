import sys
import os
from db import auth
from app import AppWindow
from PyQt6.QtWidgets import *
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon


# Окно входа - первое, что видит пользователь при запуске.
class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    # Собирает поля логина/пароля и кнопки.
    def init_ui(self):
        layout = QVBoxLayout(self)
        self.setWindowTitle("Авторизация")
        self.resize(350, 200)

        # иконка окна, если картинка лежит рядом с программой
        if os.path.exists("img1.png"):
            self.setWindowIcon(QIcon("img1.png"))

        self.lbl = QLabel("<h3>Авторизация</h3>")
        self.lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.login_line = QLineEdit()
        self.login_line.setPlaceholderText("Логин")

        # пароль скрываем точками
        self.passw_line = QLineEdit()
        self.passw_line.setPlaceholderText("Пароль")
        self.passw_line.setEchoMode(QLineEdit.EchoMode.Password)

        self.btn_login = QPushButton("Войти")
        self.btn_guest = QPushButton("Гость")

        # добавляем все элементы на форму по очереди
        for w in (self.lbl, self.login_line, self.passw_line, self.btn_login, self.btn_guest):
            layout.addWidget(w)

        self.btn_login.clicked.connect(self.try_login)
        # гость заходит без проверки - роль клиента, но без ФИО
        self.btn_guest.clicked.connect(lambda: self.main_win({'username': 'guest', 'role_name': 'client'}))

    # Проверяет введённые логин и пароль через базу данных.
    def try_login(self):
        try:
            user = auth(self.login_line.text(), self.passw_line.text())
            if user:
                QMessageBox.information(self, 'Успешно', f'Добро пожаловать, {user["first_name"]}!')
                self.main_win(user)
            else:
                QMessageBox.warning(self, 'Ошибка', 'Неверный логин или пароль')
        except Exception as e:
            # ловим проблемы с подключением к БД, чтобы программа не падала
            QMessageBox.warning(self, 'Ошибка', 'Упс, что-то не так при подключении к БД')
            print(e)

    # Открывает главное окно и закрывает окно входа.
    def main_win(self, user):
        self.win = AppWindow(user)
        self.win.show()
        self.close()


# Точка входа в программу.
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec())
